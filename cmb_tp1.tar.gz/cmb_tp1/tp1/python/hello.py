name = input("hello! What's you're name\n> ")
print("Well, it's nice to meet you", name)
